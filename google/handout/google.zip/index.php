<!-- saved from url=(0065)https://web.archive.org/web/20010805114338/http://www.google.com/ -->
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
        <title>Google</title>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>

        <style>
            body {
                font-family: arial, sans-serif;
            }
        </style>
        <script>
            <!--
            function setfocus() { document.f.q.focus(); }
            // -->
        </script>
    </head>
    <body bgcolor="#ffffff" text="#000000" link="#0000cc" vlink="551a8b" alink="#ff0000" onload="setfocus()" data-new-gr-c-s-check-loaded="14.1062.0" data-gr-ext-installed="">
        
        <center>
            <img src="./Google_files/title_homepage4.gif" width="305" height="115" alt="Google" /><br />
            <br />
            <form action="/search.php" method="post" name="f" id="search">
                <table cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr align="center" valign="baseline">
                            <td width="75">&nbsp;</td>
                            <td nowrap=""><font face="arial,sans-serif" size="-1">Search 1,387,529,000 web pages</font></td>
                            <td></td>
                        </tr>
                        <tr align="center" valign="middle">
                            <td width="75">&nbsp;</td>
                            <td align="center">
                                <input type="text" value="" framewidth="4" name="q" id="q" size="55" maxlength="256" onkeyup="search.action='search.php?q=' + q.value" /><br />
                                <div class="g-recaptcha" data-sitekey="6Lcw_OcZAAAAAJyRcmvfO9i2KhmGcG8yTQGQspBb"></div>
                                <input name="btnG" type="submit" value="Google Search" /><input name="btnI" type="submit" value="I&#39;m Feeling Lucky" />
                            </td>
                            <td nowrap="" valign="top" align="left">
                                <font face="arial,sans-serif" size="-2">
                                    <a href="https://web.archive.org/web/20010805114338/http://www.google.com/advanced_search">Advanced&nbsp;Search</a><br />
                                    <a href="https://web.archive.org/web/20010805114338/http://www.google.com/preferences">Preferences</a>
                                </font>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
            <table border="0" cellspacing="0" cellpadding="5" align="center">
                <tbody>
                    <tr valign="top" align="center">
                        <td>
                            <font size="-1" face="arial,sans-serif">
                                <a href="https://web.archive.org/web/20010805114338/http://directory.google.com/"><b>Google Web Directory</b></a><br />
                                <i>the web organized by topic</i><br />
                            </font>
                        </td>
                        <td>&nbsp;</td>
                        <td>
                            <font face="arial,sans-serif" size="-1">
                                <a href="https://web.archive.org/web/20010805114338/http://groups.google.com/"><b>Google Groups</b></a><br />
                                <i>usenet discussion forum</i><br />
                            </font>
                        </td>
                    </tr>
                </tbody>
            </table>
            <br />
            <br />
            <b>
                First time here?
                <a
                    href="https://web.archive.org/web/20010805114338/http://www.google.com/tour/1.html"
                    target="popup"
                    onclick="window.open(&#39;&#39;,&#39;popup&#39;,&#39;scrollbars=yes,resizable=yes,width=560,height=400,left=100,top=50&#39;)"
                >
                    Take a quick tour of Google
                </a>
                .
            </b>
            <br />
            <br />
            <br />
            <font size="-1">
                <a href="https://web.archive.org/web/20010805114338/http://www.google.com/jobs/">Cool&nbsp;Jobs</a> -
                <a href="https://web.archive.org/web/20010805114338/http://www.google.com/services/">Add&nbsp;Google&nbsp;to&nbsp;Your&nbsp;Site</a> -
                <a href="https://web.archive.org/web/20010805114338/http://www.google.com/ads/">Advertise&nbsp;with&nbsp;Us</a> -
                <b><a href="https://web.archive.org/web/20010805114338/http://www.google.com/about.html">All&nbsp;About&nbsp;Google</a></b>
            </font>
            <p><font size="-2">2001 Google</font></p>
        </center>
      
    </body>
</html>
