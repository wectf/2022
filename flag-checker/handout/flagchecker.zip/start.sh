node index_server.js &
node flag_server.js &
node proxy.js &
sleep 5m
