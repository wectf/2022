node server.js &
cd logstash && ./bin/logstash -f ../log.conf 