/app/influxdb-1.8.10-1/influxd &
sleep 3s
python3 main.py
